# School ERP — Documentation (Scaffold)
This `docs/` tree is a **reader- and AI-coder–friendly** companion to the Master Specification.
It **never overrides** the spec. When in doubt, the spec wins.

> **Authoritative Sources (read-only):**
> - `SCHOOL_ERP_MASTER_SPECIFICATION.md` (Single Source of Truth)
> - `COMPLETE_SCHOOL_ERP_MASTER_DOCUMENTATION.md` (Merged details per module & activity)
> - `frontend_guide.md` (this repo's frontend companion)

## Contents
- `architecture/` — stack, multi-tenancy, workflows
- `rbac/` — roles, permissions, rate limits
- `api/` — pointers to activity tables per module
- `ui/` — EJS + Tailwind guide, partials, patterns
- `testing/` — contract & HTML rendering tests
- `contributing/` — commit format, pre-commit checks

## Usage
- Keep pages **activity-centric** (file name includes `ACTIVITY_ID` when applicable).
- Link to the spec instead of duplicating endpoint details.
- Follow the **standard API envelope** for examples.
- Do **not** invent endpoints, DTOs, or status codes.
