# Security & RBAC
- Enforce roles with middleware on **every** endpoint.
- UI should **reflect** permissions (hide) but server **enforces** (403 + audit).
