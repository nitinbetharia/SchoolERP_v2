# Roles Matrix (Pointer)
For the full, authoritative matrix and per-activity roles, see the Master Specification's **Security & RBAC** section.
Common roles include: SYSTEM_ADMIN, GROUP_ADMIN, TRUST_ADMIN, SCHOOL_ADMIN, TEACHER, ACCOUNTANT, PARENT, STUDENT.
