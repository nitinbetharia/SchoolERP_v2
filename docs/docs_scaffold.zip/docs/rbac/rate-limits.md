# Rate Limits (Pointer)
- Authentication endpoints: 5 req/min
- Fee operations: 30 req/min
- All other endpoints: 300 req/min
Implement client-side throttling and graceful handling of 429 responses.
