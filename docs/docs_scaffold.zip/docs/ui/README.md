# UI Guide
Server-rendered **EJS + Tailwind**. Activity-centric views; never invent endpoints or DTOs.
See `ui/frontend_guide.md` for hands-on patterns and prompts.
