# Testing
- **Contract tests** validate request/response conformity per activity.
- **SSR HTML tests** (Jest + Supertest + Cheerio) assert render, permissions, and error banners.
- **Definition of Done**: view exists, route calls exact endpoint, zod validation, RBAC middleware, rate-limit handling, tests passing.
