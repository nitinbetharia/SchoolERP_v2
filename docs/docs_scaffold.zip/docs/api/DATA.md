# DATA Module (Pointers)
- Connection Status: GET `/system/connections/status` (DATA-00-001)
- Master Schema: POST `/system/schemas/master` (DATA-00-002)
- Trust Registry: POST `/system/trusts` (DATA-00-005)
- Session Store: POST `/system/sessions` (DATA-00-008)
- Audit Logs: POST `/system/audit-logs/{system|tenants}` (DATA-00-009/010)
- Config Cache: PUT `/system/config/cache` (DATA-00-011)
- Pool Cleanup: POST `/system/connections/cleanup` (DATA-00-012)

> **Do not replicate full tables here.** Link to the Master Specification and annotate only UI-relevant notes (forms, tables, views).

**Standard Envelope** (responses):
```json
{ "success": true, "data": { /*...*/ } }
// or
{ "success": false, "error": { "code": "ERROR", "message": "details", "details": [], "traceId": "..." } }
```
