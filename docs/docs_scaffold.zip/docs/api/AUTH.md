# AUTH Module (Pointers)
Authentication endpoints subject to 5 req/min.

> **Do not replicate full tables here.** Link to the Master Specification and annotate only UI-relevant notes (forms, tables, views).

**Standard Envelope** (responses):
```json
{ "success": true, "data": { /*...*/ } }
// or
{ "success": false, "error": { "code": "ERROR", "message": "details", "details": [], "traceId": "..." } }
```
