# Multi-Tenancy & Trust Context
- Resolve **subdomain → trust** for every request.
- Inject `res.locals.trust = { id, slug, name, logo, theme }` for branding and context.
- Use lazy connection pools and **session isolation** across trusts.
- Provide **config cache** and invalidation mechanisms.
Reference activities: DATA-00-005, DATA-00-008, DATA-00-011 (see spec tables).
