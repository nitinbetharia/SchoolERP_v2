# Wizards & Setup Flow
- Multi-step, resumable wizards for configuration.
- Steps are strictly ordered; conditional rendering based on prior answers.
- Persist progress in session + backend endpoints.
Key activities: SETUP-01-001 .. SETUP-01-008.
