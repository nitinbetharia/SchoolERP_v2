# Stack & Modules
- **Backend:** Node.js 20 + TypeScript + Express
- **DB:** MySQL 8 (master + per-trust schemas)
- **Frontend:** SSR EJS + Tailwind CSS
- **Validation:** Zod
- **Modules:** data, setup, auth, user, stud, fees, attd, rept, dash, comm

Follow the module folder structure and activity-centric controllers as per the Master Specification.
