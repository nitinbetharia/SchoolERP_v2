# Architecture Docs
Concise, non-authoritative summaries for developers. For **exact** DTOs/endpoints, always open the Master Specification.
