# Contributing
Follow the Master Specification's pre-commit checklist and commit format.

## Pre-Commit Checklist
- TypeScript compiles without errors
- Contract tests pass
- RBAC middleware applied
- Audit logging implemented
- Error handling follows standard envelope
- DB operations use parameterized queries

## Commit Message Format
```
feat(DATA-00-001): implement connection status endpoint

- Add GET /system/connections/status
- Implement RBAC for SYSTEM_ADMIN|GROUP_ADMIN
- Add audit logging
- Add contract test
```
